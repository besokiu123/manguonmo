<?php
$products = [
    1 => ['id'=>1,'name'=>'Chó Husky','price'=>2000000,'image'=>'/frontend/images/husky.svg','description'=>'Chó Husky năng động, thân thiện.'],
    2 => ['id'=>2,'name'=>'Mèo Anh Lông Dài','price'=>1500000,'image'=>'/frontend/images/cat.svg','description'=>'Mèo Anh lông dài, dịu dàng.'],
    3 => ['id'=>3,'name'=>'Chim Vẹt','price'=>800000,'image'=>'/frontend/images/parrot.svg','description'=>'Chim vẹt thông minh, biết nói.'],
    4 => ['id'=>4,'name'=>'Cá Vàng','price'=>50000,'image'=>'/frontend/images/goldfish.svg','description'=>'Cá vàng dễ nuôi.' ],
];
